# ✪𝐄-𝐏𝐫𝐢𝐦𝐞 𝐆𝐏𝐓✪ — Release Android App

This is a release-ready Android WebView wrapper for:

`https://mayhem001-tech.github.io/EPrimeAI-Web/`

## Included
- Custom E-Prime GPT launcher artwork
- Adaptive launcher icon for Android 8+
- Legacy launcher icons for older Android versions
- Branded splash screen
- JavaScript + DOM storage enabled for the website
- Android file chooser support for Camera / Photo / Files uploads
- Microphone runtime permission + WebView audio capture support
- Android back navigation through WebView history
- Release build configuration
- GitHub Actions workflow that automatically creates a **signed release APK**

## Build a signed APK from GitHub (phone-friendly)

The repository must contain the project files at its root. No keystore or GitHub signing secrets are required.

1. Upload the contents of this project to a GitHub repository.
2. Open **Actions**.
3. Select **Build signed E-Prime GPT APK**.
4. Tap **Run workflow**.
5. Open the completed workflow run.
6. Download the **E-Prime-GPT-release-apk** artifact.

The workflow automatically creates a temporary RSA signing key on the GitHub runner, signs the release APK, and then discards the key when the job ends.

## Important signing limitation

This simplified workflow is intended for easy testing, installation, and sharing. A new signing key is generated on every workflow run. Therefore, an APK produced by one run generally **cannot be updated in place** by an APK from a later run because Android signing identities differ.

If you later want to publish this app on Google Play or distribute updates to an existing installation, switch to a permanent signing keystore and keep it backed up securely.

Do not add a keystore or passwords to the repository.
